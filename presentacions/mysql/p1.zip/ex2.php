<!DOCTYPE html>
<!--
Crea una página web que pasándole como parámetro ip nos devuelva el país al que pertenece esa IP, para ello debe llamar al servicio http://api.geoiplookup.net/?query=<ip a buscar> con el valor que pasemos como parámetro e imprimir la IP, el país y el proveedor.

La IP debe obetnerse a través de un formulario.
-->

<?php
/* Activamos los flags para que nos muestre los errores.
Este código no debería ir en producción */
ini_set('display_errors', 1);
error_reporting(E_ALL);
ini_set("display_errors", 1);
?>

<html lang="es">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
      integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
      crossorigin="anonymous"
    />
    <!-- El teu css -->
    <style></style>
    <!-- fi -->
    <title>Exericici 2</title>
  </head>


  <?php
function pr($data)
/* Esta función nos permite visualizar fácilmente el contenido de una
imprimiéndola en pantalla
 */
{
    echo "<pre>";
    var_dump($data); // or var_dump($data);
    echo "</pre>";
}

$url = "http://api.geoiplookup.net?query=";
if (isset($_GET["ip"])) {
  $url .=  $_GET["ip"];
}

if (!$xml = file_get_contents($url)) {
    echo "No se ha podido cargar el archivo";
} else {
    $xml = new SimpleXMLElement($xml);
    $root = $xml->results;
    /* pr($root); */
}
?>
  <body>
    <div class="container">
      <div class="row">
      <div class="col">
        <h2>IP Info</h2>
        <form action="<?php $_PHP_SELF ?>" method="GET">
          <input type="text" name="ip" placeholder="pon la ip">
          <input type="submit" value="info">
        </form>
        <hr>
      </div>
     <table class="table">
     <thead>
       <tr>
         <th scope="col">IP</th>
         <th scope="col">País</th>
         <th scope="col">Proveedor/IPS</th>
       </tr>
     </thead>
     <tbody>
       <?php
foreach ($root->result as $item) {
    echo '<tr>';
    echo '<td>', $item->ip, '</td>';
    echo '<td>', $item->countryname, '</td>';
    echo '<td>', $item->isp, '</td>';
    echo '</tr>';
}
?>
     </tbody>
     </table>
     <?php echo "<p>(c) Exercicis de l'aula </p>"; ?>
      </div>
</div>
</body>
</html>
