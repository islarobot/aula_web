<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <ul>
    <li><a href="ex1.php">ex1</a>
    <li><a href="ex2.php">ex2</a>
    <li><a href="ex3.php">ex3</a>
    </ul>
  </body>
</html>