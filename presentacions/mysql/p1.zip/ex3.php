<!DOCTYPE html>
<!--
Crea un formulari que demani el nom, primer llinatge i segon llinatge i l'edat i ho envii per POST  a una plana que ens ha de presentar la informació com a primer llinatge segon llinatge, nom i calculi els anys que falten per a la jubilació (suposada als 67 anys).

Per exemple:

MARTÍ
POL
FUSTER
50

Ha de mostrar:

POL FUSTER, MARTI li falte 17 ansy per jubilar-se
-->

<?php
/* Activamos los flags para que nos muestre los errores.
Este código no debería ir en producción */
ini_set('display_errors', 1);
error_reporting(E_ALL);
ini_set("display_errors", 1);
?>

<html lang="es">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS -->
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
      integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
      crossorigin="anonymous"
    />
    <!-- El teu css -->
    <style></style>
    <!-- fi -->
    <title>Exericici 2</title>
  </head>


  <?php
function pr($data)
/* Esta función nos permite visualizar fácilmente el contenido de una
imprimiéndola en pantalla
 */
{
    echo "<pre>";
    var_dump($data); // or var_dump($data);
    echo "</pre>";
}
?>
  <body>
    <div class="container">
      <div class="row">
      <div class="col">
      <form action="ex3.php" method="POST">
          <input type="text" name="nom" placeholder="nom">
          <input type="text" name="llinatge1" placeholder="primer llinatge">
          <input type="text" name="llinatge2" placeholder="segon llinatge">
          <input type="number" name="edat" placeholder="edat actual">
          <input type="submit" value="calcula">
        </form>
        <hr>
      </div>
      
       <?php
      if ($_SERVER['REQUEST_METHOD']=='POST') {
        if (is_numeric($_POST['edat'])) {
          $jubilacio = 67 - $_POST['edat'];
          if ($jubilacio<0) {
            $nom="Ja s'hauria d'haver jubilat vostè!";
          }
          else {
            $nom = " {$_POST['llinatge1']} {$_POST['llinatge2']}, {$_POST['nom']} li falten {$jubilacio} anys per jubilar-se";
          }          
       } else {
              $nom="No ha indicat l'edat! <br/>";
              }
              
       echo "<h4>{$nom}<h4>";
      }
?>
  </div><!-- row -->
     <?php echo "<p>(c) Exercicis de l'aula </p>"; ?>
      </div><!--container-->
</div>
</body>
</html>