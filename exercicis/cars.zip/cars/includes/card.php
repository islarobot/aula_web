<div class="col-md-6">
  <div class="card">
    <img class="card-img-top" src="<?php echo $cotxe['url'] ?>" alt="<?php echo $cotxe['title'] ?>" />
    <div class="card-body">
      <h5 class="card-title"><?php echo $cotxe['title'] ?></h5>
      <p class="card-text">
        <?php echo $cotxe['description'] ?>
      </p>
      <a href="ficha.php?code=<?php echo $cotxe['code'] ?>" class="btn btn-primary">Ver más</a>
    </div>
  </div>
</div>

