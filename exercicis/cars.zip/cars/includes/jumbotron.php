<div class="jumbotron">
    <h1 class="display-4">Cotxes! Cotxes!</h1>
    <p class="lead">Troba cotxes de tota casta i color</p>
</div>
