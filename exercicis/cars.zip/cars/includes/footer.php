<nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Condicions legals</a></li>
          <li class="breadcrumb-item"><a href="#">Política de privacitat</a></li>
          <li class="breadcrumb-item"><a href="#">Sobre aquesta plana</a></li>
        </ol>
      </nav>
